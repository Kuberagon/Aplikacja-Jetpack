package com.example.myapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.myapp.ui.theme.MyappTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyappTheme {
                val navController = rememberNavController()

                NavHost(navController = navController, startDestination = "screen1") {
                    composable("screen1") { Screen1(navController) }
                    composable("screen2") { Screen2(navController) }
                    composable("screen3") { Screen3(navController) }
                }
            }
        }
    }
}

@Composable
fun Screen1(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Screen 1",
            style = TextStyle(fontSize = 24.sp, color = Color.Black)
        )

        Button(
            onClick = { navController.navigate("screen2") },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Green) // Zielony przycisk
        ) {
            Text(text = "Przejdź do Screen 2")
        }

        Button(
            onClick = { navController.navigate("screen3") },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Blue) // Niebieski przycisk
        ) {
            Text(text = "Przejdź do Screen 3")
        }
    }
}

@Composable
fun Screen2(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Screen 2",
            style = TextStyle(fontSize = 24.sp, color = Color.Black)
        )

        Button(
            onClick = { navController.navigate("screen1") },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Black) // Czarny przycisk
        ) {
            Text(text = "Przejdź do Screen 1", color = Color.White) // Biały tekst dla czytelności
        }

        Button(
            onClick = { navController.navigate("screen3") },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Blue) // Niebieski przycisk
        ) {
            Text(text = "Przejdź do Screen 3")
        }
    }
}

@Composable
fun Screen3(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Screen 3",
            style = TextStyle(fontSize = 24.sp, color = Color.Black)
        )

        Button(
            onClick = { navController.navigate("screen1") },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Black) // Czarny przycisk
        ) {
            Text(text = "Przejdź do Screen 1", color = Color.White) // Biały tekst dla czytelności
        }

        Button(
            onClick = { navController.navigate("screen2") },
            colors = ButtonDefaults.buttonColors(containerColor = Color.Green) // Zielony przycisk
        ) {
            Text(text = "Przejdź do Screen 2")
        }
    }
}
